<div class="main-heandler">

    <div class="slide">
        <div style="padding: 10% 0">
            <p>Будь собой!</p>
            <p>Будь черлидером!</p>
        </div>

        <a href="/">подробнее  </a>
    </div>
</div>
<div class="ourTeams">
    <h2><span>&#9733;</span>Наши черлидеры<span>&#9733;</span></h2>
</div>
<div class="wrapper">
    <div class="teamsList">
        <div class="liTeams" id="team-1">
            <p><a href="/"><span>Baby group</span><img src="../../img/main/arrow_go.jpg" width="36" height="48"></a> </p>
        </div>
        <div class="liTeams" id="team-2">
            <p><a href="/"><span>Junior group</span><img src="../../img/main/arrow_go.jpg" width="36" height="48"></a> </p>
        </div>
        <div class="liTeams" id="team-3">
            <p><a href="/"><span>Cheers group</span><img src="../../img/main/arrow_go.jpg" width="36" height="48"></a> </p>
        </div>
        <div class="liTeams" id="team-4">
            <p><a href="/"><span>Hip-Hop group</span><img src="../../img/main/arrow_go.jpg" width="36" height="48"></a> </p>
        </div>
    </div>
</div>

<div style="display: block;"><h2><span class="h2span">&#9733;</span> ПОЧЕМУ МЫ НАЙДЕМ ОБЩИЙ ЯЗЫК? <span class="h2span">&#9733;</span></h2></div>
<div class="wrapper">
    <div class="adv">

        <ul>
            <li>
                <img src="/img/adv-11.jpg">
                <p>Cомневаешься, что у тебя получится? У тебя точно получится!
                Все наши занятия создаются с ориентиром на дитей с любым уровнем спортивной подготовки,
                и мы полностью за приятное времяпрепровождение!</p>
            </li>
            <li>
                <img src="/img/adv-12.jpg">
                <p>С тобой всегда рядом такие же энтузиасты — ты становишься частью сообщества
                и приобретаешь новых друзей (и да, это возможно в любом возрасте)</p>
            </li>
            <li>
                <img src="/img/adv-13.jpg">
                <p>Вы будете заниматься под крылом профессионального тренера,
                    влюбленного в свою дисциплину!</p>
            </li>
            <li>
                <img src="/img/adv-14.jpg">
                <p>Мы — клуб для тех, кому интересно освоить новые виды спорта.
                Вы не просто пробуете, а именно осваиваете, узнаете спорт изнутри.</p>
            </li>
            <li>
                <img src="/img/adv-5.jpg">
                <p>Можно не останавливаться на одном, продолжи осваивать новые виды танцев.
                В нашем клубе мы всегда экспериментируем и вскоре создаим в новые интересные группы!</p>
            </li>

        </ul>

    </div>
</div>

<div class="coaches">
    <hr>
    <div id="coach-1">
        <a href="/">
            <img src="/img/coach-1.png" id="coach-1-1">
            <img src="/img/coach-1_1.png" id="coach-1-2" style="display: none;">
            <p style="margin-bottom: 0; padding-left: 28%;">Сергей</p>
			<p style="margin-top: 0; padding-left: 26%;">Высоцкий</p>	
        </a>
    </div>
    <div id="coach-2">
        <a href="/">
            <img src="/img/coach-2.png" id="coach-2-1">
            <img src="/img/coach-2_1.png" id="coach-2-2" style="display: none;">
            <p style="margin-bottom: 0; padding-left: 50%;">Анастасия</p>
			<p style="margin-top: 0; padding-left: 49%;">Paфальская</p>
        </a>
    </div>
</div>
<div class="post-news">
    <h3>
        О НАС ПИШУТ, ГОВОРЯТ И ПОКАЗЫВАЮТ
    </h3>
    <div class="wrapper">
        <div style="display: inline-block">
            <div class="li-post">
                <a href="/"><img src="../../img/main/facebook-3.svg" width="100"></a>
            </div>
        </div>

    </div>

</div>
<div id="bottom" >
    <div class="social-icons" >
        <div class="wrapper">


            <ul class="social-list">
                <li>
                    <h4 id="social-title">connect</h4>
                </li>
                <li>
                    <a href="https://www.facebook.com/" target="_blank" title="Мы в Facebook">
                        <img class="icon" src="/img/main/facebook.png">DS-Forma on Facebook
                    </a>
                </li>
                <li>
                    <a href="http://vk.com/" target="_blank" title="Мы в VK">
                        <img class="icon" src="/img/main/vk_com1600.png">DS-Forma on VK
                    </a>

                </li>
                <li>
                    <a href="http://www.youtube.com/" target="_blank" title="Мы в YouTube">
                        <img class="icon" src="/img/main/youtube-3-xxl.png">DS-Forma on YouTube
                    </a>
                </li>
                <li>
                    <a href="http://instagram.com/" target="_blank" title="Мы в Instagram">
                        <img class="icon" src="/img/main/Instagram-PNG-File.png">DS-Forma on Instagram
                    </a>

                </li>
            </ul>
        </div>
    </div>
    <div style="height: 45vh; background: white; ">
        <div class="wrapper">
            <div id="bottom-form">
                <img src="/img/main/bottom.png">
                <div id="bottom-post">
                    <p >Уже после первого месяца тренировок Вы поймете, что нашли то самое
                    увлекательное занятие для Вашего ребенка.
                        <br>
                        <br>
                        <a href="/" style="background: yellow; margin-top: 8vh; padding: 1vh; border: 1px solid black; text-align: center;">Записаться на занятие</a>
                    </p>

                </div>
            </div>

        </div>
    </div>
    <div class="wrapper">
        <section class="subscribe">
            <h3 class="subscribe__title">Дальше скроллить некуда –&nbsp;пора подписаться на нашу рассылку</h3>
            <form action="/" method="post" class="subscribe-form">
                <fieldset class="subscribe-form__group">
                    <input class="subscribe-form__field" type="email" name="email" placeholder="youmail@somemail.ru">
                    <input type="hidden" name="type" value="common">
                    <input class="btn subscribe-form__btn" type="submit" value="Подписаться">
                </fieldset>
            </form>

        </section>
    </div>
</div>



